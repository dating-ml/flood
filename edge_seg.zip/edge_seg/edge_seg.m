
function edge_seg(mdir, edir)
% mdir = '/mnt/data/datasets/coseg/vase/obj'
 % edir = '/mnt/data/datasets/coseg/seg/split/vase/vase_500_rh_rewrite/obj'

lst = dir([edir filesep  '**/*.edges']);
% lst = dir([edir filesep  '*.edges']);
tol = 1e-8;

parfor i=1:length(lst)
    nmdir = strrep(lst(i).folder, edir, mdir);
    nedir = lst(i).folder;
    nm = lst(i).name;
    fnm = [nedir filesep nm]; % fnm = [edir filesep nm];
    [~,nm1,~] = fileparts(nm);
    mnm0 = [nmdir filesep nm1 '.obj']; %[mdir filesep nm1 '.obj'];
    msh0 = read_obj_fast(mnm0);
    segf = [nmdir filesep nm1 '.seg']; %[mdir filesep nm1 '.seg'];
    seg = dlmread(segf);
    mnm1 = [nedir filesep nm1 '.obj'];
    msh1 = read_obj_fast(mnm1);
    edges1 = dlmread(fnm);
    edges1 = edges1 + 1;
    verts1 = msh1.vertices;
    ne = size(edges1,1);
    
    faces = msh0.faces;
    nf = size(faces,1);
    verts = msh0.vertices;
    tmp = verts(faces(:,1),:);
    [normals, areas] = mesh_face_normals(msh0);
    pl = [tmp normals];
    globs = [1 0 0; 0 1 0; 0 0 1];
    
    %sege = zeros(ne,1);
    odir = [nedir filesep 'seg']; %[edir filesep 'seg']
    if(~exist(odir, 'dir'))
        mkdir(odir);
    end
%     odir = nedir;
    segef = [odir filesep nm1 '.eseg'];
    
    allv = [];
    nump = 5;
    curr = 1;
    rows = [];
    cols = [];
    
    for e=1:ne
        cv0 = verts1(edges1(e,:),:);
        x = linspace(cv0(1,1), cv0(2,1), nump);
        y = linspace(cv0(1,2), cv0(2,2), nump);
        z = linspace(cv0(1,3), cv0(2,3), nump);
        cv = [x' y' z'];
        allv = [allv; cv];
        row = e * ones(1,nump);
        rows = [rows row];
        col = curr:curr+nump-1;
        cols = [cols col];
        curr = curr + nump;
    end
    
    lookup = sparse(rows,cols,ones(size(rows)),ne,ne*nump);
    dsts = zeros(size(allv,1), nf);
    
    for k=1:nf
        
        cn = normals(k,:);
        plp = verts(faces(k,:),:);
        dp = distancePointPlane2(allv, [plp(1,:) cn]);
        angs = vec_angles(repmat(cn, 3 ,1), globs);
        angs = angs - pi/2;
        [~,mind] = max(abs(angs));
        glob = globs(mind,:);
        
        plp2 = projPointOnPlane2(plp, [0 0 0 glob]);
        allv2 = projPointOnPlane2(allv, [0 0 0 glob]);
            
        rem = setdiff([1 2 3], mind);
        tmp1 = allv2(:,rem);
        tmp2 = plp2(:,rem);
        
        inp = inpolygon(tmp1(:,1), tmp1(:,2), tmp2(:,1), tmp2(:,2));
        inpi = find(inp);
        dsts(inpi,k) = dp(inpi);
        ninpi = find(~inp);
        
        d1 = distancePointEdge3d(allv(ninpi,:), [plp(1,:) plp(2,:)]);
        d2 = distancePointEdge3d(allv(ninpi,:), [plp(2,:) plp(3,:)]);
        d3 = distancePointEdge3d(allv(ninpi,:), [plp(3,:) plp(1,:)]);
        md = min([d1 d2 d3],[],2);
        dsts(ninpi,k) = md;
%         for j=1:length(ninpi)
%             d1 = distancePointEdge3d(allv(ninpi(j),:), [plp(1,:) plp(2,:)]);
%             d2 = distancePointEdge3d(allv(ninpi(j),:), [plp(2,:) plp(3,:)]);
%             d3 = distancePointEdge3d(allv(ninpi(j),:), [plp(3,:) plp(1,:)]);
%             md = min([d1 d2 d3]);
%             dsts(ninpi(j),k) = md;
%         end
    end
    
    dsts = abs(dsts);
    mdsts = min(dsts,[],2);
    tmp = bsxfun(@minus, dsts, mdsts);
    tmp2 = find(abs(tmp) < tol);
    [a,b] = ind2sub(size(dsts), tmp2);
    
    segb = seg(b);
    tmp3 = sparse(a,segb,ones(size(a)),ne*nump,max(seg));
    smat = lookup * tmp3;
    [~,mxind] = max(smat,[],2);
    
    %sege(e) = mode(seg(b));
    sege = mxind;
    
    dlmwrite(segef, sege);
end

end

