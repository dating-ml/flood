
function ang = vec_angles(vec1, vec2)

%ang = atan2(norm(cross(vec1,vec2,2)),dot(vec1,vec2,2));

nr1 = mat_norm(vec1, 2);
nr2 = mat_norm(vec2, 2);

costheta = dot(vec1,vec2,2)./(nr1.*nr2);
%costheta = dot(vec1,vec2)/(norm(vec1)*norm(vec2));
%if(costheta > 1)
%    costheta = 1;
%end
costheta(find(costheta > 1)) = 1;
costheta(find(costheta < -1)) = -1;
ang = acos(costheta);

end
