
function nr = mat_norm(A, dim)

invr = 0;

if(exist('dim', 'var'))
    
    if(dim == 2)
        A = A';
        invr = 1;
    end
end

tmp = A .^ 2;
tmp2 = sum(tmp);
nr = sqrt(tmp2);

if(invr)
    nr = nr';
end

end