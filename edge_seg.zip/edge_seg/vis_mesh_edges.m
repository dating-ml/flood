
function vis_mesh_edges(msh, edges, seg)

f = msh.faces;
v = msh.vertices;

e = edges';
e = e + 1;

ev = v(e(:),:);
ev = reshape(ev,2*size(e,2),3);

figure;
hold on;

mp = [1 0 0; 0 1 0; 0 0 1; 0 1 1];


for i=1:2:size(ev,1)
    cv = ev(i:i+1,:);
    plot3(cv(:,1),cv(:,2),cv(:,3),'-','color',mp(seg((i+1)/2),:));

end

end



% function vis_mesh_edges(msh, seg)
% 
% f = msh.faces;
% v = msh.vertices;
% 
% %mp = colormap('Lines');
% e = [f(:,1) f(:,2); f(:,2) f(:,3); f(:,3) f(:,1)];
% se = sort(e,2);
% [e, ind] = unique(se,'rows');
% e = e';
% 
% ev = v(e(:),:);
% ev = reshape(ev,2*size(e,2),3);
% 
% figure;
% hold on;
% 
% sg = seg(ind);
% 
% for i=1:2:size(ev,1)
%     cv = ev(i:i+1,:);
%     plot3(cv(:,1),cv(:,2),cv(:,3),'b-');
%     %hold on;
% end
% 
% end
