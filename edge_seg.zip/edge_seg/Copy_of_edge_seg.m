
function edge_seg(mdir, edir)

lst = dir([edir filesep '*.edges']);
tol = 1e-8;

for i=1:length(lst)
    nm = lst(i).name;
    fnm = [edir filesep nm];
    [~,nm1,~] = fileparts(nm);
    mnm0 = [mdir filesep nm1 '.obj'];
    msh0 = read_obj_fast(mnm0);
    segf = [mdir filesep nm1 '.seg'];
    seg = dlmread(segf);
    mnm1 = [edir filesep nm1 '.obj'];
    msh1 = read_obj_fast(mnm1);
    edges1 = dlmread(fnm);
    verts1 = msh1.vertices;
    ne = size(edges1,1);
    
    faces = msh0.faces;
    nf = size(faces,1);
    verts = msh0.vertices;
    tmp = verts(faces(:,1),:);
    [normals, areas] = mesh_face_normals(msh0);
    pl = [tmp normals];
    globs = [1 0 0; 0 1 0; 0 0 1];
    
    sege = zeros(ne,1);
    odir = [edir filesep 'seg'];
    if(~exist(odir, 'dir'))
        mkdir(odir);
    end
    segef = [odir filesep nm1 '.eseg'];
    
    for e=1:ne
        cv0 = verts1(edges1(e,:),:);
        x = linspace(cv0(1,1), cv0(2,1), 5);
        y = linspace(cv0(1,2), cv0(2,2), 5);
        z = linspace(cv0(1,3), cv0(2,3), 5);
        cv = [x' y' z'];
        
        dsts = zeros(size(cv,1), nf);
        
        for k=1:nf
            
            cn = normals(k,:);
            plp = verts(faces(k,:),:);
            dp = distancePointPlane2(cv, [plp(1,:) cn]);
            angs = vec_angles(repmat(cn, 3 ,1), globs);
            angs = angs - pi/2;
          	[~,mind] = max(abs(angs));
            glob = globs(mind,:);

            plp2 = projPointOnPlane2(plp, [0 0 0 glob]);
            cv2 = projPointOnPlane2(cv, [0 0 0 glob]);
            
            rem = setdiff([1 2 3], mind);
            tmp1 = cv2(:,rem);
            tmp2 = plp2(:,rem);

            inp = inpolygon(tmp1(:,1), tmp1(:,2), tmp2(:,1), tmp2(:,2));
            inpi = find(inp);
            dsts(inpi,k) = dp(inpi);
            ninpi = find(~inp);
            
            for j=1:length(ninpi)
                d1 = distancePointEdge3d(cv(ninpi(j),:), [plp(1,:) plp(2,:)]);
                d2 = distancePointEdge3d(cv(ninpi(j),:), [plp(2,:) plp(3,:)]);
                d3 = distancePointEdge3d(cv(ninpi(j),:), [plp(3,:) plp(1,:)]);
                md = min([d1 d2 d3]);
                dsts(ninpi(j),k) = md;
            end
            
            %if(~isempty(find(inp == 1)))
            %   disp(['bla!  ', num2str(dp(1)), '  ', num2str(dp(2))])
            %end
            bla = 1;
        end
        
        dsts = abs(dsts);
        mdsts = min(dsts,[],2);
        tmp = bsxfun(@minus, dsts, mdsts);
        tmp2 = find(abs(tmp) < tol);
        [a,b] = ind2sub(size(dsts), tmp2);
        
        sege(e) = mode(seg(b));
        
%         mdsts = min(abs(dsts));
%         [mdst, mind] = min(mdsts);
%         diff = abs(mdsts - mdst);
%         rel = find(diff < tol);
        
        
%         d1 = distancePointPlane2(cv(1,:), pl);
%         d2 = distancePointPlane2(cv(2,:), pl);
%         pp1 = projPointOnPlane2(cv(1,:), pl);
%         pp2 = projPointOnPlane2(cv(2,:), pl);
%         inp = inpolygon(tmp1(:,1), tmp1(:,2), tmp2(:,1), tmp2(:,2));
        bla = 1;
    end
    
    dlmwrite(segef, sege);
    
    bla = 1;
end

end

