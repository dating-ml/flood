%
% This function reads an obj file and returns a mesh structure
%
% function [M, status] = mesh_read_obj(filename)
%
% Input -
%   - filename: name of obj file to load
%
% Output -
%   - M: triangle mesh: M.vertices(i, :) represents the 3D coordinates
%   of vertex 'i', while M.faces(i, :) contains the indices of the three
%   vertices that compose face 'i'. If the mesh also has color
%   attributes, they are stored in M.FaceVertexCData
%   - status: this variable is 0 if the file was succesfuly opened, or 1
%   otherwise
%
%   The input mesh is similar to that read by the mesh_read_smf
%   function, but the way of specifying colors changes.
%
% See also mesh_read, mesh_read_smf
%
function P = read_obj_fast(filename)
%
% Copyright (c) 2008, 2009, 2010 Oliver van Kaick <ovankaic@cs.sfu.ca>
%

    % Open file
    fid = fopen(filename);
    status = 0;
    if fid == -1
        disp(['ERROR: could not open file "' filename '"']);
        M = [];
        status = 1;
        return;
    end

    % Read content
%     P = [];
%     %P.n = [];
%     P.vertices = [];
%     P.faces = [];
    
    vet = [];
    fat = [];
    
    while(feof(fid) ~= 1)
        
        line = '';
        line = fgetl(fid);
        
        
        % A line needs at least two characters to be meaningful
        if length(line) <= 1
            continue;
        end
        if (line(1) == 'v') && (line(2) == ' ')
            line = line(3:length(line));
            %P.vertices(end+1, :) = sscanf(line, '%f %f %f');
            temp = sscanf(line, '%f %f %f');
            vet = [vet; temp];
            ve = fscanf(fid, 'v %f %f %f\n');
            vet = [vet; ve];
        elseif (line(1) == 'f') && (line(2) == ' ')
           line = line(3:length(line));
           temp = sscanf(line, '%d/%d/%d %d/%d/%d %d/%d/%d');
           if length(temp) < 9
               temp = sscanf(line, '%d/%d %d/%d %d/%d');
               temp2 = sscanf(line, '%d//%d %d//%d %d//%d');
               if length(temp) < 6 && length(temp2) < 6
                   temp = sscanf(line, '%d %d %d');
                   fa = fscanf(fid, 'f %d %d %d\n');
               else
                   if(length(temp) == 6)
                        temp = temp(1:2:end);
                        fa = fscanf(fid, 'f %d/%d %d/%d %d/%d\n');
                        fa = fa(1:2:end);
                   else
                        temp = temp2(1:2:end);
                        fa = fscanf(fid, 'f %d//%d %d//%d %d//%d\n');
                        fa = fa(1:2:end);
                   end
               end
           else
               temp = temp(1:3:end);
               fa = fscanf(fid, 'f %d/%d/%d %d/%d/%d %d/%d/%d\n');
               fa = fa(1:3:end);
           end
%            temp = sscanf(line, '%d/%d %d/%d %d/%d');
%            if length(temp) < 6
%                temp = sscanf(line, '%d %d %d');
%                fa = fscanf(fid, 'f %d %d %d\n');
%            else
%                temp = temp(1:2:end);
%                fa = fscanf(fid, 'f %d/%d %d/%d %d/%d\n');
%                fa = fa(1:2:end);
%            end
           fat = [fat; temp; fa];
        end
        
        
%         ve = fscanf(fid, 'v %f %f %f\n');
%         fa = fscanf(fid, 'f %d %d %d\n');
%         fa2 = fscanf(fid, 'f %d/%d %d/%d %d/%d\n');
%         
%         if(isempty(ve) && isempty(fa) && isempty(fa2))
%             fgetl(fid);
%             continue;
%         end
%         
%         vet = [vet; ve];
%         fat = [fat; fa];
%         if(~isempty(fa2))
%             fat = [fat; fa2(1:2:end)];
%         end
        


%         line = '';
%         line = fgetl(fid);
%         
%         
%         % A line needs at least two characters to be meaningful
%         if length(line) <= 1
%             continue;
%         end
%         if (line(1) == 'v') && (line(2) == ' ')
%             line = line(3:length(line));
%             P.vertices(end+1, :) = sscanf(line, '%f %f %f');
%        elseif (line(1) == 'f') && (line(2) == ' ')
%            line = line(3:length(line));
%            temp = sscanf(line, '%d/%d %d/%d %d/%d');
%            if length(temp) < 6
%                P.faces(end+1, :) = sscanf(line, '%d %d %d');
%            else
%                P.faces(end+1, :) = temp([1 3 5]);
%            end
%         end
    end


    % Close file
    fclose(fid);
    
    vet2 = reshape(vet, 3, length(vet) / 3);
    fat2 = reshape(fat, 3, length(fat) / 3);
    
    P.vertices = vet2';
    P.faces = fat2';

end
